import 'dart:async';

import 'package:expense_tracker/core/network/connectivity_service.dart';
import 'package:expense_tracker/data/datasources/local/hive_category_datasource.dart';
import 'package:expense_tracker/data/datasources/remote/firebase_category_datasource.dart';
import 'package:expense_tracker/data/models/category_model.dart';
import 'package:expense_tracker/domain/entities/category_entity.dart';
import 'package:expense_tracker/domain/entities/transaction_entity.dart';
import 'package:expense_tracker/domain/repositories/category_repository.dart';

/// Offline-first implementation of [CategoryRepository].
///
/// Categories are not user-scoped for local storage (they're shared), but
/// Firestore stores them under `users/{userId}/categories` for per-user
/// customization.
class CategoryRepositoryImpl implements CategoryRepository {
  final HiveCategoryDatasource _localDatasource;
  final FirebaseCategoryDatasource _remoteDatasource;
  final ConnectivityService _connectivity;

  CategoryRepositoryImpl({
    required HiveCategoryDatasource localDatasource,
    required FirebaseCategoryDatasource remoteDatasource,
    required ConnectivityService connectivity,
  })  : _localDatasource = localDatasource,
        _remoteDatasource = remoteDatasource,
        _connectivity = connectivity;

  // ---------------------------------------------------------------------------
  // Read
  // ---------------------------------------------------------------------------

  @override
  Future<List<CategoryEntity>> getCategories() async {
    final localModels = _localDatasource.getAll();
    return localModels.map((m) => m.toEntity()).toList();
  }

  @override
  Future<List<CategoryEntity>> getCategoriesByType(
      TransactionType type) async {
    final typeInt = type == TransactionType.income ? 0 : 1;
    final models = _localDatasource.getByType(typeInt);
    return models.map((m) => m.toEntity()).toList();
  }

  @override
  Future<CategoryEntity?> getCategoryById(String id) async {
    final model = _localDatasource.getById(id);
    return model?.toEntity();
  }

  // ---------------------------------------------------------------------------
  // Write
  // ---------------------------------------------------------------------------

  @override
  Future<void> addCategory(CategoryEntity entity) async {
    final model = CategoryModel.fromEntity(entity);
    await _localDatasource.add(model);

    if (await _connectivity.isConnected) {
      try {
        await _remoteDatasource.add(entity.id, model);
      } catch (_) {
        // Will be synced later
      }
    }
  }

  @override
  Future<void> updateCategory(CategoryEntity entity) async {
    final model = CategoryModel.fromEntity(entity);
    await _localDatasource.update(model);

    if (await _connectivity.isConnected) {
      try {
        await _remoteDatasource.update(entity.id, model);
      } catch (_) {
        // Will be synced later
      }
    }
  }

  @override
  Future<void> deleteCategory(String id) async {
    await _localDatasource.delete(id);

    if (await _connectivity.isConnected) {
      try {
        // userId not available here — fire-and-forget; the remote
        // listener or next sync will reconcile
        await _remoteDatasource.delete(id, id);
      } catch (_) {
        // Best-effort
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Streams
  // ---------------------------------------------------------------------------

  @override
  Stream<List<CategoryEntity>> watchCategories() {
    return _localDatasource.box
        .watch()
        .map((_) =>
            _localDatasource.getAll().map((m) => m.toEntity()).toList());
  }

  // ---------------------------------------------------------------------------
  // Sync
  // ---------------------------------------------------------------------------

  @override
  Future<void> syncCategories(String userId) async {
    if (!await _connectivity.isConnected) return;

    try {
      // Push all local categories to remote
      final localModels = _localDatasource.getAll();
      if (localModels.isNotEmpty) {
        await _remoteDatasource.syncBatch(userId, localModels);
      }

      // Pull remote categories into local
      final remoteModels = await _remoteDatasource.getAll(userId);
      await _localDatasource.replaceAll(remoteModels);
    } catch (_) {
      // Non-critical — we continue with local data
    }
  }

  @override
  Future<List<CategoryEntity>> getDefaultCategories() async {
    final models = _localDatasource.getDefaults();
    return models.map((m) => m.toEntity()).toList();
  }
}
