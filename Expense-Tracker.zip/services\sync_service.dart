import 'package:flutter/foundation.dart';

import 'package:expense_tracker/core/network/connectivity_service.dart';
import 'package:expense_tracker/data/datasources/local/transaction_local_datasource.dart';
import 'package:expense_tracker/data/datasources/local/category_local_datasource.dart';
import 'package:expense_tracker/data/datasources/local/budget_local_datasource.dart';
import 'package:expense_tracker/data/datasources/remote/transaction_remote_datasource.dart';
import 'package:expense_tracker/data/datasources/remote/category_remote_datasource.dart';
import 'package:expense_tracker/data/datasources/remote/budget_remote_datasource.dart';
import 'package:expense_tracker/data/models/transaction_model.dart';
import 'package:expense_tracker/data/models/category_model.dart';
import 'package:expense_tracker/data/models/budget_model.dart';
import 'package:expense_tracker/domain/entities/transaction_entity.dart';
import 'package:expense_tracker/domain/entities/category_entity.dart';
import 'package:expense_tracker/domain/entities/budget_entity.dart';

/// Result of a sync operation with statistics about what changed.
class SyncResult {
  final int pushed;
  final int pulled;
  final int conflicts;
  final List<String> errors;

  const SyncResult({
    this.pushed = 0,
    this.pulled = 0,
    this.conflicts = 0,
    this.errors = const [],
  });

  SyncResult merge(SyncResult other) {
    return SyncResult(
      pushed: pushed + other.pushed,
      pulled: pulled + other.pulled,
      conflicts: conflicts + other.conflicts,
      errors: [...errors, ...other.errors],
    );
  }

  bool get hasErrors => errors.isNotEmpty;

  @override
  String toString() =>
      'SyncResult(pushed=$pushed, pulled=$pulled, '
      'conflicts=$conflicts, errors=${errors.length})';
}

/// Service that handles bidirectional synchronization between local Hive storage
/// and remote Firestore.
///
/// Sync strategy: **Last-Write-Wins** — when the same record exists both
/// locally and remotely, the version with the more recent `createdAt` timestamp
/// is kept.
///
/// Usage:
/// ```dart
/// final syncService = SyncService(...);
/// await syncService.syncAll(userId);
/// ```
class SyncService {
  SyncService({
    required ConnectivityService connectivityService,
    required TransactionLocalDatasource transactionLocalDatasource,
    required TransactionRemoteDatasource transactionRemoteDatasource,
    required CategoryLocalDatasource categoryLocalDatasource,
    required CategoryRemoteDatasource categoryRemoteDatasource,
    required BudgetLocalDatasource budgetLocalDatasource,
    required BudgetRemoteDatasource budgetRemoteDatasource,
  })  : _connectivity = connectivityService,
        _txLocal = transactionLocalDatasource,
        _txRemote = transactionRemoteDatasource,
        _catLocal = categoryLocalDatasource,
        _catRemote = categoryRemoteDatasource,
        _budgetLocal = budgetLocalDatasource,
        _budgetRemote = budgetRemoteDatasource;

  final ConnectivityService _connectivity;

  // Transaction datasources
  final TransactionLocalDatasource _txLocal;
  final TransactionRemoteDatasource _txRemote;

  // Category datasources
  final CategoryLocalDatasource _catLocal;
  final CategoryRemoteDatasource _catRemote;

  // Budget datasources
  final BudgetLocalDatasource _budgetLocal;
  final BudgetRemoteDatasource _budgetRemote;

  /// Whether a sync is currently in progress (prevents overlapping syncs).
  bool _isSyncing = false;
  bool get isSyncing => _isSyncing;

  // ---------------------------------------------------------------------------
  // Full Sync
  // ---------------------------------------------------------------------------

  /// Synchronize all data (transactions, categories, budgets) for [userId].
  ///
  /// This is the primary entry point, typically called:
  /// 1. On app startup after login.
  /// 2. When network connectivity is restored.
  ///
  /// Returns a combined [SyncResult] with statistics across all data types.
  Future<SyncResult> syncAll(String userId) async {
    if (_isSyncing) {
      debugPrint('SyncService: Sync already in progress — skipping');
      return const SyncResult();
    }

    final isConnected = await _connectivity.isConnected;
    if (!isConnected) {
      debugPrint('SyncService: No network connection — skipping sync');
      return const SyncResult(
        errors: ['No network connection available'],
      );
    }

    _isSyncing = true;
    debugPrint('SyncService: Starting full sync for user=$userId');

    try {
      final txResult = await syncTransactions(userId);
      final catResult = await syncCategories(userId);
      final budgetResult = await syncBudgets(userId);

      final combined = txResult.merge(catResult).merge(budgetResult);
      debugPrint('SyncService: Full sync complete — $combined');
      return combined;
    } catch (e) {
      debugPrint('SyncService: Full sync failed — $e');
      return SyncResult(errors: ['Full sync failed: $e']);
    } finally {
      _isSyncing = false;
    }
  }

  // ---------------------------------------------------------------------------
  // Transaction Sync
  // ---------------------------------------------------------------------------

  /// Bidirectional sync of transactions for [userId].
  ///
  /// 1. Push: Local unsynced transactions → Firestore.
  /// 2. Pull: Firestore transactions → Local (with conflict resolution).
  Future<SyncResult> syncTransactions(String userId) async {
    int pushed = 0;
    int pulled = 0;
    int conflicts = 0;
    final errors = <String>[];

    try {
      // ── Step 1: Push unsynced local transactions to remote ──
      final localTransactions = await _txLocal.getAllTransactions();
      final unsynced = localTransactions.where((t) => !t.isSynced).toList();

      for (final localTx in unsynced) {
        try {
          final model = TransactionModel.fromEntity(localTx);
          await _txRemote.createTransaction(model);

          // Mark as synced locally
          final syncedEntity = TransactionEntity(
            id: localTx.id,
            userId: localTx.userId,
            amount: localTx.amount,
            type: localTx.type,
            categoryId: localTx.categoryId,
            note: localTx.note,
            date: localTx.date,
            createdAt: localTx.createdAt,
            recurrence: localTx.recurrence,
            isSynced: true,
          );
          await _txLocal.updateTransaction(
            TransactionModel.fromEntity(syncedEntity),
          );
          pushed++;
        } catch (e) {
          errors.add('Failed to push transaction ${localTx.id}: $e');
        }
      }

      // ── Step 2: Pull remote transactions and merge locally ──
      final remoteTransactions = await _txRemote.getTransactionsByUser(userId);
      final localMap = <String, TransactionEntity>{};
      for (final tx in localTransactions) {
        localMap[tx.id] = tx;
      }

      for (final remoteModel in remoteTransactions) {
        try {
          final remoteEntity = remoteModel.toEntity();
          final localEntity = localMap[remoteEntity.id];

          if (localEntity == null) {
            // New from remote — insert locally
            final syncedModel = TransactionModel.fromEntity(
              TransactionEntity(
                id: remoteEntity.id,
                userId: remoteEntity.userId,
                amount: remoteEntity.amount,
                type: remoteEntity.type,
                categoryId: remoteEntity.categoryId,
                note: remoteEntity.note,
                date: remoteEntity.date,
                createdAt: remoteEntity.createdAt,
                recurrence: remoteEntity.recurrence,
                isSynced: true,
              ),
            );
            await _txLocal.createTransaction(syncedModel);
            pulled++;
          } else {
            // Conflict resolution: last-write-wins based on createdAt
            if (remoteEntity.createdAt.isAfter(localEntity.createdAt)) {
              final syncedModel = TransactionModel.fromEntity(
                TransactionEntity(
                  id: remoteEntity.id,
                  userId: remoteEntity.userId,
                  amount: remoteEntity.amount,
                  type: remoteEntity.type,
                  categoryId: remoteEntity.categoryId,
                  note: remoteEntity.note,
                  date: remoteEntity.date,
                  createdAt: remoteEntity.createdAt,
                  recurrence: remoteEntity.recurrence,
                  isSynced: true,
                ),
              );
              await _txLocal.updateTransaction(syncedModel);
              conflicts++;
              pulled++;
            }
          }
        } catch (e) {
          errors.add('Failed to pull transaction: $e');
        }
      }
    } catch (e) {
      errors.add('Transaction sync failed: $e');
    }

    final result = SyncResult(
      pushed: pushed,
      pulled: pulled,
      conflicts: conflicts,
      errors: errors,
    );
    debugPrint('SyncService: Transactions — $result');
    return result;
  }

  // ---------------------------------------------------------------------------
  // Category Sync
  // ---------------------------------------------------------------------------

  /// Bidirectional sync of categories for [userId].
  Future<SyncResult> syncCategories(String userId) async {
    int pushed = 0;
    int pulled = 0;
    int conflicts = 0;
    final errors = <String>[];

    try {
      // ── Push local categories to remote ──
      final localCategories = await _catLocal.getAllCategories();

      for (final localCat in localCategories) {
        try {
          final model = CategoryModel.fromEntity(localCat);
          // Upsert: create or update on remote
          await _catRemote.upsertCategory(model, userId);
          pushed++;
        } catch (e) {
          errors.add('Failed to push category ${localCat.id}: $e');
        }
      }

      // ── Pull remote categories and merge locally ──
      final remoteCategories = await _catRemote.getCategoriesByUser(userId);
      final localMap = <String, CategoryEntity>{};
      for (final cat in localCategories) {
        localMap[cat.id] = cat;
      }

      for (final remoteModel in remoteCategories) {
        try {
          final remoteEntity = remoteModel.toEntity();
          final localEntity = localMap[remoteEntity.id];

          if (localEntity == null) {
            // New from remote — insert locally
            await _catLocal.createCategory(
              CategoryModel.fromEntity(remoteEntity),
            );
            pulled++;
          } else {
            // For categories, remote wins if names differ (simple merge)
            if (remoteEntity.name != localEntity.name ||
                remoteEntity.iconCode != localEntity.iconCode ||
                remoteEntity.colorValue != localEntity.colorValue) {
              await _catLocal.updateCategory(
                CategoryModel.fromEntity(remoteEntity),
              );
              conflicts++;
              pulled++;
            }
          }
        } catch (e) {
          errors.add('Failed to pull category: $e');
        }
      }
    } catch (e) {
      errors.add('Category sync failed: $e');
    }

    final result = SyncResult(
      pushed: pushed,
      pulled: pulled,
      conflicts: conflicts,
      errors: errors,
    );
    debugPrint('SyncService: Categories — $result');
    return result;
  }

  // ---------------------------------------------------------------------------
  // Budget Sync
  // ---------------------------------------------------------------------------

  /// Bidirectional sync of budgets for [userId].
  Future<SyncResult> syncBudgets(String userId) async {
    int pushed = 0;
    int pulled = 0;
    int conflicts = 0;
    final errors = <String>[];

    try {
      // ── Push local budgets to remote ──
      final localBudgets = await _budgetLocal.getAllBudgets();

      for (final localBudget in localBudgets) {
        try {
          final model = BudgetModel.fromEntity(localBudget);
          await _budgetRemote.upsertBudget(model, userId);
          pushed++;
        } catch (e) {
          errors.add('Failed to push budget ${localBudget.id}: $e');
        }
      }

      // ── Pull remote budgets and merge locally ──
      final remoteBudgets = await _budgetRemote.getBudgetsByUser(userId);
      final localMap = <String, BudgetEntity>{};
      for (final budget in localBudgets) {
        localMap[budget.id] = budget;
      }

      for (final remoteModel in remoteBudgets) {
        try {
          final remoteEntity = remoteModel.toEntity();
          final localEntity = localMap[remoteEntity.id];

          if (localEntity == null) {
            // New from remote — insert locally
            await _budgetLocal.createBudget(
              BudgetModel.fromEntity(remoteEntity),
            );
            pulled++;
          } else {
            // Last-write-wins: compare spent amounts — higher spent = more recent
            // Also update if budget amount changed on remote
            if (remoteEntity.spent > localEntity.spent ||
                remoteEntity.amount != localEntity.amount) {
              await _budgetLocal.updateBudget(
                BudgetModel.fromEntity(remoteEntity),
              );
              conflicts++;
              pulled++;
            }
          }
        } catch (e) {
          errors.add('Failed to pull budget: $e');
        }
      }
    } catch (e) {
      errors.add('Budget sync failed: $e');
    }

    final result = SyncResult(
      pushed: pushed,
      pulled: pulled,
      conflicts: conflicts,
      errors: errors,
    );
    debugPrint('SyncService: Budgets — $result');
    return result;
  }
}
